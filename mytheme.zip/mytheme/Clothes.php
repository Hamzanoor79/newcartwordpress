<?php
 /****
 Template Name:Clothes 
 *****/
 get_header();
  
  global $post;

  $array=array(
        'post_type'=>'clothes',
        'post_status' => 'publish',
        'posts_per_page' => 8, 
        'orderby' => 'title', 
        'order' => 'ASC', 
  );

  $loop=new WP_Query($array);
?>

<div class="container">
  <div class="row mt-4">   
<?php
 while ( $loop->have_posts() ) : $loop->the_post(); 
  $clothes_name=get_post_meta($post->ID,'clothe_product_name',true);
  $clothe_price=get_post_meta($post->ID,'clothe_price',true);
  $clothe_description=get_post_meta($post->ID,'clothe_description',true);
  $upload_picture=get_post_meta($post->ID,'upload_picture',true);

  $post_pic=wp_get_attachment_url($upload_picture);
?>
  
  <div class="col-sm-4">
       <div class="card">
        <img class="card-img-top" src="<?php echo  $post_pic ?>" alt="Card image" style="width:100%">
        <div class="card-body">
          <h4 class="card-title"><?php echo $clothes_name ?></h4>
          <p class="card-text">Price: <span class="price"><?php echo $clothe_price ?></span></p>
          <p class="card-text"><?php echo $clothe_description ?></p>
            <input type="number" name="quantity" class="clothe_qua">

            <br>
           
          <div class="mt-2 add_cartdiv">
           
           <a href="javascript:void(0)" class="btn btn-primary buynow" data-product="<?php echo $post->ID?>" data-user="<?php echo $_SESSION['userrecord']->data->ID;?>">Buy Now</a>

           <a href="javascript:void(0)" class="btn btn-primary add_cart_clothes" data-product="<?php echo $post->ID?>" data-user="<?php echo $_SESSION['userrecord']->data->ID;?>">Add to cart</a>
          
          </div>

        </div>
      </div>
  </div>

<?php
endwhile;
?>
 

  </div>

</div>

<?php
wp_footer();
?>