<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel='stylesheet' href='https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap.min.css'>

<style>
.custab{
    border: 1px solid #ccc;
    padding: 5px;
    box-shadow: 3px 3px 2px #ccc;
    transition: 0.5s;
    }
.custab:hover{
    box-shadow: 3px 3px 0px transparent;
    transition: 0.5s;
    }
    
    .add_recipet_admin{
        margin-left:5px;
    }
    
    fieldset.scheduler-border {
    border: 1px groove #ddd !important;
    padding: 0 1.4em 1.4em 1.4em !important;
    margin: 16px 0 1.5em 0 !important;
    box-shadow:  0px 0px 0px 0px #000;
}

    legend.scheduler-border {
        font-size: 1.2em !important;
        font-weight: bold !important;
        text-align: left !important;
        width:auto;
        padding:0 10px;
        border-bottom:none;
    }
    
</style>

<?php 

global $wpdb;

$hiturl=wp_remote_get("http://localhost/cart_wordpress/wp-json/userdata/v1/all_users");
$result=wp_remote_retrieve_body($hiturl);
$jsondata=json_decode($result);
$apiresult=$jsondata->data;
    //  $post=wp_remote_get('http://localhost/cart_wordpress/wp-json/instantshopping/v1/all_order');
    // $order= wp_remote_retrieve_body($post);
    // $decode=json_decode($order);
    // $newdata=$decode->data;
    // $totalorder=count($newdata);
?>






    <div class='col-sm-12' style='padding-left:0px'>
           <div class='col-sm-6' style='padding-left:0px'> <h3> All Orders</h3>
            <p><?php echo $totalorder ?> Order Found!</p>
            </div>
    </div>
    
    <div class="row col-md-12 custyle">
            <div class='thumbnail'>
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User Name</th>
                                <th>User Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                      
                     <?php 
                       $i=1;
                     foreach ($apiresult as $key => $value) { 
                     
                      ?> 
                      
                      <tr>
                        <td><?php echo $i?></td>
                			  <td><?php echo $value->user_login?></td>
                			  <td><?php echo $value->user_email?></td>
                        
                        <td>
                        <a href="javascript:void(0)" data-id="<?php echo $value->ID?>" class="btn btn-primary userdetailnew" data-toggle="modal" data-target="#userdetail">View Detail</a>
                      </td>
                			
                      </tr>

                    <?php $i++; } ?>

                        </tbody>
                    </table>
            </div>
    </div>
    
    <!-- Modal -->
<div class="modal fade" id="userdetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Order Detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>User Login</th>
        <th>User Email</th>
      </tr>
    </thead>
    <tbody class="user_detailtext">
    </tbody>
  </table>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      
      </div>
    </div>
  </div>
</div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src='https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js'></script>
    <script src='https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap.min.js'></script>
    <script>
    jQuery(document).ready(function($) {
       $('#example').DataTable({
        "order": [[ 0, "desc" ]]
    });
      } );
    </script>
 