<?php
 /****
 Template Name:Login
 *****/
 wp_head();
?>

<div class="container">
	
	<div class="row">
       <div class="col-sm-12">
       	   
       	   <?php if(isset($_SESSION['user_inserted_status']) && ($_SESSION['user_inserted_status']=='yes')){ ?>

       	   <div class="alert alert-success" role="alert">
            Success! <strong><?php echo $_SESSION['user_inserted_message'] ?></strong>
            </div>

        <?php }else if($_SESSION['user_inserted_status']=='no'){ ?>
             

       	   <div class="alert alert-danger" role="alert">
              Failed! <strong><?php echo $_SESSION['user_inserted_message'] ?></strong>
            </div>  

          <?php }unset($_SESSION['user_inserted_message']);unset($_SESSION['user_inserted_status']); ?>
       </div>    
    </div>
        
       

	<div class="Signupform mt-4">  
	    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'))?>">
          
          <input type="hidden" name="action" value="login_form">
            
           
		  <div class="form-group">
		    <label>Enter Email address</label>
		    <input type="email" class="form-control" name="emailaddress"  placeholder="Enter email address">
		  </div>

		  <div class="form-group">
		    <label>Enter Password</label>
		    <input type="password" class="form-control" name="password" placeholder="Enter Password">
		  </div>

		  <button type="submit" class="btn btn-primary">Submit</button>
	  </form>
   </div>

</div>

<?php
wp_footer();
?>