<?php
/*silence is gold*/