<?php
 /****
 Template Name:Signup
 *****/
 wp_head();
?>

<div class="container">
	
	<div class="Signupform mt-4">  
	    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'))?>">
          
          <input type="hidden" name="action" value="signup_form">
            
           <div class="form-group">
		    <label>Enter Username</label>
		    <input type="text" class="form-control" name="username" placeholder="Enter Username">
		  </div>

		  <div class="form-group">
		    <label>Enter Email address</label>
		    <input type="email" class="form-control" name="emailaddress"  placeholder="Enter email address">
		  </div>

		  <div class="form-group">
		    <label>Enter Password</label>
		    <input type="password" class="form-control" name="password" placeholder="Enter Password">
		  </div>

		  <button type="submit" class="btn btn-primary">Submit</button>
	  </form>

	  <a href="<?php echo site_url()?>/login/" class="btn btn-primary"> Login</a>
   </div>

</div>

<?php
wp_footer();
?>