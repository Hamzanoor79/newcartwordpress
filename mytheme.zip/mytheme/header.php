<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<?php wp_head(); ?>
</head>


<div class="container-fluid">

 <?php if(isset($_SESSION['userrecord'])){ ?>
        <div class="row mt-4">
        	 <div class="col-sm-12">

        	 	<div class="dropdown">
					  
					  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					   <?php  $name=$_SESSION['userrecord']->data->user_login;
                             echo $name;
					    ?>
					  </button>

					  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
					    <a class="dropdown-item" href="#">Action</a>
					    <a class="dropdown-item" href="<?php echo site_url()?>/clothes/">Clothes</a>
					    <a class="dropdown-item" href="<?php echo site_url() ?>/shopping-cart">Shopping Cart <?php if(isset($_SESSION['cart'])){ 
                              $totalitem=count($_SESSION['cart']);
					    	?>
					    <span class="badge badge-light"><?php echo $totalitem ?></span>
                           <?php } ?>
					    </a>
					    <a class="dropdown-item" href="<?php echo site_url() ?>/?action=logout">Logout</a>
					  </div>
					</div>
        	 	
        	 </div>
        </div>

    <?php } ?>

</div>