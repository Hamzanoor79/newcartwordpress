<?php
class userapi
{
	public function __construct()
 	{
 		 global $wpdb;
 		 add_action("rest_api_init",array($this,'userapis_data'));
 	}

 	public function userapis_data(){
 		register_rest_route('userdata/v1','/all_users/',array(
           
           array(
               "methods"=>"get",
               "callback"=>array($this,'userrecord'),
               "args"=>array()
           )
 		));
 	}

 	public function userrecord(){
        global $wpdb;
 		  $query=$wpdb->get_results("select* from wp_users");
 		  $response['data']=$query;
 		  return $response;
 	}
}