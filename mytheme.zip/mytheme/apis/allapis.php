<?php
 class instantshopping
 {
 	
 	public function __construct()
 	{
 		global $wpdb;
 		add_action('rest_api_init',array($this,'instantshoppingRestApiRoutes'));
 	}

 	public function instantshoppingRestApiRoutes(){
 		 register_rest_route('instantshopping/v1','/all_order/',array(
           
           array(
               "methods"=>'get',
               "callback"=>array($this,'showorders'),
               "args"=>array()
           )

 		 ));
 	}

 	public function showorders(){
 		 global $wpdb;
 		 $query=$wpdb->get_results("select * from wp_order");
 		 $response['data']=$query;
 		 return $response;
 	}
 }