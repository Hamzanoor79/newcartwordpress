<?php

require_once('libs/stripe/init.php');

function enqueue_style_script_admin()
{
wp_enqueue_script('stripe-js','https://js.stripe.com/v3/');
}
add_action('wp_footer','enqueue_style_script_admin');

function cssfiles(){

	wp_enqueue_style('bootstrap','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css',array(),false,false);



	wp_enqueue_style('fontawesom','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css',array(),false,false);

       
    wp_enqueue_style('stylefile',get_stylesheet_directory_uri().'/assets/style.css',array(),false);


    wp_enqueue_script('jquery');

 

    wp_enqueue_script('jsfile',get_stylesheet_directory_uri().'/js/custom.js',array(),true,true);


  wp_enqueue_script('prelaoder-js',get_stylesheet_directory_uri().'/js/jquery.preloaders.js',array(),true,true);


    $arraydata=array(
        'ajax_url'=>admin_url('admin-ajax.php'),
        "theme_url" => get_template_directory_uri().'/imgs/',
    );


wp_enqueue_script('slimjs','https://code.jquery.com/jquery-3.2.1.slim.min.js',array(),false,true);


   	wp_enqueue_script('popperjs','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js',array(),false,true);


	wp_enqueue_script('bootstrapjs','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js',array(),false,true);



    wp_localize_script('jsfile','js_data',$arraydata);
	}

add_action('wp_enqueue_scripts','cssfiles');


add_action('admin_enqueue_scripts','adminjsfiles');

function adminjsfiles(){
  
  wp_enqueue_script('adminjs',get_stylesheet_directory_uri().'/js/admin.js',array(),true,true);

   $arrayadmin=array(
     "admin_ajaxul"=>admin_url('admin-ajax.php')
   );

   wp_localize_script('adminjs','admin_newjs',$arrayadmin);

} 


function register_my_session()
{
  if( !session_id() )
  {
    session_start();
  }
}

add_action('init', 'register_my_session');

add_action('wp_ajax_add_cart','add_cart');
add_action('wp_ajax_nopriv_add_cart','add_cart');

function add_cart(){

	$quantity=$_POST['quantity'];
	$price=$_POST['price'];
	$product_id=$_POST['product_id'];
     
    $product['product_id']=$product_id;
    $product['price']=$price;
    $product['quantity']=$quantity;

    $product['total']=$price*$quantity;
    $_SESSION['cart'][]=$product;  
    
    $total_item=count($_SESSION['cart']);
    
    if(isset($_SESSION['cart'])){
         $response['status']=1;
         $response['message']="Added to cart";
         $response['total']=$total_item;
    }else{
         $response['status']=2;
         $response['message']="Not Added to cart";
    }

    echo json_encode($response);
      wp_die();
}

add_action('wp_ajax_add_clothes','add_clothes');
add_action('wp_ajax_nopriv_add_clothes','add_clothes');
function add_clothes(){
  $price=$_POST['price'];
  $quantity=$_POST['quantity'];
  $product_id=$_POST['product_id'];
  
}


add_action('wp_ajax_submitorderajax','submitorderajax');
add_action('wp_ajax_nopriv_submitorderajax','submitorderajax');

function submitorderajax(){
  $quantity=$_POST['quantity'];
  $price=$_POST['price'];
  $product_id=$_POST['product_id'];

 global $wpdb;
  $data=$_SESSION['cart'];
  $userid=$_SESSION['userrecord']->data->ID;
  
    
     $datanew=array(
         "user_id"=>$userid,
         "total"=>10
       ); 
     
     $insert=$wpdb->insert('wp_order',$datanew);
     $latestorder=$wpdb->insert_id;


   foreach ($data as $key => $value) {

     $price=$value["price"];
     $quantity=$value["quantity"];

     $order_detail=array(
       'orderid'=>$latestorder,
       'product_id'=>$value["product_id"],
       'quantity'=>$quantity,
       'price'=>$price
     );
      
     $wpdb->insert('wp_order_detail',$order_detail);

     $total_new=$price*$quantity;
     $total=$total+$total_new; 
   }
   

   $update=$wpdb->update('wp_order',array("total"=>$total),array("orderid"=>$latestorder));

    if($update){
      
      unset($_SESSION['cart']);

      $_SESSION['order_status']='yes';
      $_SESSION['order_message']="Order Confirmed";
    
   }else{
      $_SESSION['order_status']='no';
      $_SESSION['order_message']="Something went wrong";
   }

   wp_redirect(home_url());
   exit();

  var_dump($product_id);
}

add_action('admin_post_signup_form','signup_form');
add_action('admin_post_nopriv_signup_form','signup_form');

function signup_form(){
	global $wpdb;
	$username=$_POST['username'];
	$emailaddress=$_POST['emailaddress'];
	$password=$_POST['password'];
       
    $newuser=array(
     "user_login"=>$username,
     "user_pass"=>$password,
     "user_nicename"=>$username,
     "user_email"=>$emailaddress
    ); 

   $insert=wp_insert_user($newuser);

   if(!is_wp_error($insert))
   {
   	  $_SESSION['user_inserted_status']='yes';
      $_SESSION['user_inserted_message']="New user Inserted";
   
   }else{
       $_SESSION['user_inserted_status']='no';
      $_SESSION['user_inserted_message']="Something went wrong";
   }

   wp_redirect(home_url('login'));
   exit();
}

add_action('admin_post_login_form','login_form');
add_action('admin_post_nopriv_login_form','login_form');

function login_form(){
  $emailaddress=$_POST['emailaddress'];
  $password=$_POST['password'];
  
  $loginuser=array(
    'user_login'=>$emailaddress,
    'user_password'=>$password
  );
   $sign_in=wp_signon($loginuser,false);
     
    
   if(!is_wp_error($sign_in)){
      
      $_SESSION['userrecord']=$sign_in;
   	  $_SESSION['user_login_status']='yes';
      $_SESSION['user_login_message']="Login Successfully";
   
   }else{   
   	  $_SESSION['user_login_status']='no';
      $_SESSION['user_login_message']="Something went wrong";
   }

   wp_redirect(home_url());
   exit();
}

if(isset($_GET['action']) &&  $_GET['action']=='logout'){
     session_start();
    unset($_SESSION['userrecord']);
    session_destroy();
    wp_redirect(home_url('login'));
    exit;
}

add_action('after_setup_theme', 'remove_admin_bar');
function remove_admin_bar() {
    if (!current_user_can('administrator') && !is_admin()) {
      show_admin_bar(false);
    }
}

add_action('admin_post_confirm_order','confirm_order');
add_action('admin_post_nopriv_confirm_order','confirm_order');

function confirm_order(){
      
      global $wpdb;
	$data=$_SESSION['cart'];
	$userid=$_SESSION['userrecord']->data->ID;
    

      
	  
	   $datanew=array(
         "user_id"=>$userid,
         "total"=>10
       ); 
     
     $insert=$wpdb->insert('wp_order',$datanew);
     $latestorder=$wpdb->insert_id;


   foreach ($data as $key => $value) {

   	 $price=$value["price"];
   	 $quantity=$value["quantity"];

   	 $order_detail=array(
       'orderid'=>$latestorder,
       'product_id'=>$value["product_id"],
       'quantity'=>$quantity,
       'price'=>$price
   	 );
      
     $wpdb->insert('wp_order_detail',$order_detail);

   	 $total_new=$price*$quantity;
     $total=$total+$total_new; 
   }
   

   $update=$wpdb->update('wp_order',array("total"=>$total),array("orderid"=>$latestorder));

    if($update){
      
      unset($_SESSION['cart']);

      $_SESSION['order_status']='yes';
      $_SESSION['order_message']="Order Confirmed";
    
   }else{
      $_SESSION['order_status']='no';
      $_SESSION['order_message']="Something went wrong";
   }

   wp_redirect(home_url());
   exit();
}
/***************show orders***************************/
add_action('admin_menu','all_order');
function all_order(){
	add_menu_page('Allorders','All orders','manage_options','all_orders','allorders','',10);
}

function allorders(){
	require_once('admin_panel/allorders.php'); 
}
/***************end show orders***************************/

/***************apis***********************************/
 // require_once('apis/allapis.php');
 // $instantshopping_APIs = new instantshopping();
  
  require_once('apis/userapis.php');
  $userapis=new userapi();
/***************end apis******************************/

add_action('wp_ajax_order_detail','order_detail');
add_action('wp_ajax_nopriv_order_detail','order_detail');

function order_detail(){
	global $wpdb;
	global $post;
	$id=$_POST['id'];
	$query=$wpdb->get_results("select * from wp_order_detail where orderid='$id'");
     $i=1;
	foreach ($query as $key => $value) { 
        
        $price=$value->quantity*$value->price; 
       $total=$total+$price;

       $args = array('p' => $value->product_id, 'post_type' => 'products');
       $loop = new WP_Query($args);
      
       while ( $loop->have_posts() ) : $loop->the_post(); 
            
            $product_name=get_post_meta ($post->ID,'product_name', true ); 
       
		?>
	 
	    <tr>
        <td><?php echo $i ?></td>
        <td><?php echo $product_name?></td>
        <td><?php echo $value->quantity ?></td>
        <td><?php echo $value->price ?></td>
      </tr>

<?php
	 $i++; endwhile;} ?>
     
     <tr>
      	 <td  colspan="4" style="text-align: right;">Total: <?php echo $total?></td>
      </tr>
<?php	 
}

add_action('wp_ajax_delete_order','delete_order');
add_action('wp_ajax_nopriv_delete_order','delete_order');

function delete_order(){
	$id=$_POST['id'];

	unset($_SESSION['cart'][$id]);
      
        $response['status']=1;
        $response['delete_msg']="Item deleted";
    
    echo json_encode($response);
    wp_die();
}

add_action('admin_menu','all_users');
function all_users(){
    add_menu_page("AllUsers","AllUsers","manage_options",'all_users_record','all_userdata');
}  

function all_userdata(){
  require_once('admin_panel/allusers.php');
}

add_action('wp_ajax_user_detail','user_detail');
add_action('wp_ajax_nopriv_user_detail','user_detail');
function user_detail(){
  global $wpdb;
  $userid=$_POST['id'];
  $query=$wpdb->get_results("select * from wp_users where ID='$userid'");
  
  $newi=1;
  foreach ($query as $key => $value) { ?>
      
      <tr>
        <td><?php echo $newi ?></td>
        <td><?php echo $value->user_login ?></td>
        <td><?php echo $value->user_email ?></td>
      </tr>

  <?php  
  $newi++;}

} 

add_action('wp_ajax_buynow','buynow');
add_action('wp_ajax_nopriv_buynow','buynow');

function buynow(){

  global $wpdb;
  $price=$_POST['price'];
  $productname=$_POST['productname'];
  $userid=$_POST['userid'];
  $productid=$_POST['productid'];

 \Stripe\Stripe::setApiKey('sk_test_51HvmvWCFLwW8wbDl8MnALtHHbs5car5VeTDwmmQISZhrzf6Pb3olriZfhIwk09zmKvctwXjoRAbRhG5KQwL9HSQO00WSUg4uJX');
              $checkout_session = \Stripe\Checkout\Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [[
                'price_data' => [
                  'currency' => 'gbp',
                  'unit_amount' => $price*100,
                  'product_data' => [
                  'name' => 'Lucky4kids Competition',
                  'images' => [site_url()."/wp-content/uploads/2021/06/cropped-newlogog.png"],
                  ],
                ],
                'quantity' => 1,
                ]],
                'mode' => 'payment',
                'metadata'=>['order_id'=>$productid,'userid'=>$userid],
                'success_url' => 'http://localhost/cart_wordpress/thankyou/',
                'cancel_url' => site_url(),
              ]);
              
              
              $transaction = array(
                "productprice"=>$price,
                "productname"=>$productname
              );

              $insert =$wpdb->insert('wp_payment',$transaction);

               if($insert){
                 $response['error'] = false;
                 $response['status'] =1;
                 $response['id'] = $checkout_session->id;
         }else{
          $response['status'] =2;
               $response['error'] =  true;
         }
              echo json_encode($response);
              die;
}