<?php get_header(); ?>

<?php
global $post;
 $args = array(  
        'post_type' => 'products',
        'post_status' => 'publish',
        'posts_per_page' => 8, 
        'orderby' => 'title', 
        'order' => 'ASC', 
    );

    $loop = new WP_Query( $args ); 
 
   $cart=$_SESSION['cart'];

?>
<body>


<div class="row">
       <div class="col-sm-12">
       	   
       	   <?php if(isset($_SESSION['user_login_status']) && ($_SESSION['user_login_status']=='yes')){ ?>

       	   <div class="alert alert-success" role="alert">
            Success! <strong><?php echo $_SESSION['user_login_message'] ?></strong>
            </div>

        <?php }else if($_SESSION['user_login_status']=='no'){ ?>
             

       	   <div class="alert alert-danger" role="alert">
              Failed! <strong><?php echo $_SESSION['user_login_message'] ?></strong>
            </div>  

          <?php }unset($_SESSION['user_login_message']);unset($_SESSION['user_login_status']); ?>

           

       	   <?php if(isset($_SESSION['order_status']) && ($_SESSION['order_status']=='yes')){ ?>

       	   <div class="alert alert-success" role="alert">
            Success! <strong><?php echo $_SESSION['order_message'] ?></strong>
            </div>

        <?php }else if($_SESSION['order_status']=='no'){ ?>
             

       	   <div class="alert alert-danger" role="alert">
              Failed! <strong><?php echo $_SESSION['order_message'] ?></strong>
            </div>  

          <?php }unset($_SESSION['order_status']);unset($_SESSION['order_message']); ?>

       </div>    
    </div>


<div class="container-fluid">
    <div class="row mt-4 ml-2">
    	
    	<?php
           
           $i=1;
    	 while ( $loop->have_posts() ) : $loop->the_post(); 

        $product_name=get_post_meta ($post->ID,'product_name', true );
        $enter_product_price=get_post_meta ($post->ID,'enter_product_price', true );
        $enter_product_description=get_post_meta ($post->ID,'enter_product_description', true );

       $productimage=get_post_meta ($post->ID,'product_image', true );
	   $imgurl = wp_get_attachment_url($productimage);
    	?>
    	<div class="col-sm-4">
           
           <div class="card" style="width: 18rem;">
			 
			  <img class="card-img-top product_img" src="<?php echo $imgurl ?>" alt="Card image cap">
			 
			  <div class="card-body">
			    <h5 class="card-title"><?php echo $product_name?></h5>
			    <input type="hidden" name="product_id" class="product_id" value="<?php echo $post->ID?>">
			    <p>RS. <span class="product_price"><?php echo $enter_product_price ?></span></p>
			    <input type="text" class="form-control quantity" placeholder="Enter quantity">
			    <p class="card-text"><?php echo $enter_product_description?></p>
                
                <?php 
                 
                 if(!empty($_SESSION['cart']))   
                  { 
                foreach ($cart as $key => $value) {
                	 $data[]=$value['product_id'];
                } 
                   if(in_array($post->ID,$data))
                   {
                   	 ?>
                     
                     <a href="#" class="btn btn-primary">Added</a>

                  <?php }else{ ?>
                  	 
                  	 <a href="#" class="btn btn-primary add_cart">Add to cart</a>
                
                <?php } }else{ ?>					
                
                 <a href="#" class="btn btn-primary add_cart">Add to cart</a>
                
                <?php } ?>
			  </div>
		  
		  </div>
              <p class="showerror<?php echo $post->ID?>"></p>
    	</div>
       
       <?php  $i++; endwhile; ?>
    </div>
</div>
</body>
<?php get_footer(); ?>