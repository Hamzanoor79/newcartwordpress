<?php
 /****
 Template Name:Shopping Cart
 *****/
 get_header();

  $cart=$_SESSION['cart'];

?>

<div class="container">
  <div class="row">
     <div class="col-sm-12 mt-3 newchild">
         
         <?php 
          
          if(!empty($cart))
          {
           
            ?>

            
            <h1>Total: <span class="totaldatanew"></span></h1>
           <?php 
           

           global $post;

           $i=0;

          foreach ($cart as $key => $value) {
           



       $args = array('p' => $value["product_id"], 'post_type' => 'products');
       $loop = new WP_Query($args);
      
       while ( $loop->have_posts() ) : $loop->the_post(); 
            
            $product_name=get_post_meta ($post->ID,'product_name', true ); 
             $enter_product_price=get_post_meta ($post->ID,'enter_product_price', true );
             
              $enter_product_description=get_post_meta ($post->ID,'enter_product_description', true );

             $productimage=get_post_meta ($post->ID,'product_image', true );
             $imgurl = wp_get_attachment_url($productimage);
               
               $totalprice=$totalprice+$value['total'];

             

          ?>
         
         <div class="col-sm-4 shopping_cart">
           
           <div class="card" style="width: 18rem">      
        <img class="card-img-top product_img" src="<?php echo $imgurl ?>" alt="Card image cap">
       
        <div class="card-body">
          <h5 class="card-title"><?php echo $product_name?></h5>
          <p>RS. <span class="product_price"><?php echo $value['total'] ?></span></p>
          
          <input type="hidden" name="product_id" class="product_id" value="<?php echo $post->ID?>">


          <input type="hidden" name="product_id" class="product_quantity" value="<?php echo $value['quantity'] ?>">

          
          <p class="card-text"><?php echo $enter_product_description?></p>  
        </div>
      
      </div>

          <button type="button" class="btn btn-danger mt-3 dangerdata" data-id="<?php echo $i?>">Delete</button>
          
      </div>
       
       <?php endwhile;  $i++;} ?>

     </div>

     <div class="col-sm-12 mt-3 orderbtndata">
          
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'))?>">
                  <input type="hidden" name="action" value="confirm_order">
                 <button type="submit" class="btn btn-primary">Submit</button>  
                 
          </form>

           <button type="button" class="btn btn-primary mt-2 submit_order">Submit</button>


     </div>


            <input type="hidden" name="totalprice" class="total_price" value="<?php echo $totalprice?>">

      <?php }else{ ?>
         <h3>No Product in cart</h3>
      <?php } ?>

  </div>
</div>

<?php
wp_footer();
?>