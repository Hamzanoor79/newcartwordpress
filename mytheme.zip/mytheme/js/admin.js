jQuery(document).ready(function($) {
     
     $('.orderdetail').click(function(){
        var id=$(this).attr('data-id');
        $.ajax({
                url:admin_newjs.admin_ajaxul,
                type:'post',
                data:{id:id,'action':'order_detail'},
                success:function(html){
                  $('.order_detailtext').html(html);
                }
        });
     });


     $('.userdetailnew').click(function(){
         var id=$(this).attr('data-id');
         $.ajax({
              url:admin_newjs.admin_ajaxul,
              type:'post',
              data:{id:id,'action':'user_detail'},
              success:function(html){
                 $('.user_detailtext').html(html);
              }
         });
     });

});