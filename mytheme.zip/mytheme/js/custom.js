jQuery(document).ready(function($) {
 
  var stripe = Stripe('pk_test_51HvmvWCFLwW8wbDlWNnaj4wQd8TKt7JmkG4vHoGzx0YE8ZWDXvQ8d8g2jwSQUHG5xlKwLT3XCMVZWjzsON1JaqT40086J0H9BD');

   $('.add_cart').click(function(){
        
        var quantity=$(this).siblings('.quantity').val();
        var price=$(this).siblings('p').children('.product_price').text();
        var product_id=$(this).siblings('.product_id').val();
       

       $.ajax({
             url:js_data.ajax_url,
             type:'post',
             data:{quantity:quantity,price:price,product_id:product_id,'action':'add_cart'},
             dataType:'json',
             success:function(html){
                if(html.status==1)
                {
                  $('.showerror'+product_id).html(html.message);
                  $('.badge').html(html.total);
                }if(html.status==2)
                {
                  $('.showerror'+product_id).html(html.message);

                }
             }
       });

   });

   $('.add_cart_clothes').click(function(){
      var price=$(this).parent('.add_cartdiv').parent('.card-body').children('.card-text').find('.price').text();
      var quantity=$(this).parent('.add_cartdiv').parent('.card-body').children('.clothe_qua').val();
      var product_id=$(this).attr('data-product');

      $.ajax({
           url:,
           type:'post',
           data:{price:price,quantity:quantity,product_id:product_id,'action':'add_clothes'},
           dataType:'json',
           success:function(html){

           }
      });
   });

 $('.dangerdata').click(function(){
      var id=$(this).attr('data-id');
 
 var data=confirm("Are you sure you want to delete");


 if(data==true)
    { 
      $.ajax({
          url:js_data.ajax_url,
          type:'post',
          data:{id:id,"action":"delete_order"},
          dataType:'json',
            beforeSend: function() {
          $('.dangerdata'+id).html('deleting <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');
              },
          success:function(html){
            if(html.status==1)
            {
              alert(html.delete_msg);
              window.location.href="http://localhost/cart_wordpress/shopping-cart/";
            }
          }
      });
     } 
  });

$('.submit_order').click(function(){
       var price=$(this).parent('.orderbtndata').siblings('.newchild').children('.shopping_cart').children('.card').find('.product_price').text();
         // $(this).parent('.orderbtndata').siblings('.newchild').children('.shopping_cart').children('.card').find('.product_price').css({"color": "red", "border": "2px solid red"});
        var quantity=$(this).parent('.orderbtndata').siblings('.newchild').children('.shopping_cart').children('.card').find('.product_quantity').val();
        var product_id=$(this).parent('.orderbtndata').siblings('.newchild').children('.shopping_cart').children('.card').find('.product_id').val();
         
         // alert(quantity);

        $.ajax({
                  url:js_data.ajax_url,
                  type:'post',
                  data:{quantity:quantity,price:price,product_id:product_id,'action':'submitorderajax'},
                  dataType:'json',
                  beforeSend:function(){
                        $.preloader.start({
                  modal: true,
                  src : js_data.theme_url+"loader.svg"
                });
                       // $('.submit_order').html('Ordering <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>');   
                  },
                  success:function(html){
                    $.preloader.stop();
                  }
        });
});
   
   $(document).ready(function(){
        var price=$('.total_price').val();
        $('.totaldatanew').html(price);
   });

 $('.buynow').click(function(){
     var price=$(this).parent('.card-body').children('.card-text').find('.price').text();
     var productname=$(this).parent('.card-body').children('.card-title').text();
     var userid=$(this).attr('data-user');
     var productid=$(this).attr('data-product'); 
      $.ajax({
                url:js_data.ajax_url,
                type:'post',
                data:{userid:userid,productid:productid,price:price,productname:productname,'action':'buynow'},
                beforeSend:function(){

                $.preloader.start({
                  modal: true,
                  src : js_data.theme_url+"loader.svg"
                });

                },
                dataType:'json',
                success:function(html){
                    $.preloader.stop();
                    if(html.status==2){
                        alert(html.error_message);
                    }else{  
                      return stripe.redirectToCheckout({ sessionId: html.id });
                        //window.location.href="https://winnerswish.com/?page_id=1752";
                    }
   
                } 
      });
  });

});