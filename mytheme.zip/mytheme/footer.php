<?php wp_footer(); ?>
</html>
